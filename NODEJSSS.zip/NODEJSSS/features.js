// const myname = "Muhammad Hamza Malik";
// export const mynam2 ="Ali";
// export const mynam3 ="ili";

// // module.exports = myname;
// export default myname;
// // export {mynam2, mynam3};
export const genrerateLovePercent = () => {
    return `${~~(Math.random()*100)}%`
}